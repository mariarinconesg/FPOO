package datos;
import database.conexion;
import entidades.usuarios;
import interfaces.crud;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class usuariosDao implements crud<usuarios>{
    private final conexion CON;
    private PreparedStatement ps;
    private ResultSet rs;
    private boolean resp;

    
    public usuariosDao(){
        CON=conexion.getInstancia();
    }
    
    
    @Override
    public List<usuarios> listar(String texto) {
        List<usuarios> registros=new ArrayList();
        try {
            ps=CON.conectar().prepareStatement("SELECT * FROM usuarios WHERE nombre LIKE ?");
            ps.setString(1,"%" + texto +"%");
            rs=ps.executeQuery();
            while(rs.next()){
                registros.add(new usuarios(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getInt(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getInt(10), rs.getBoolean(11)));
            }
            ps.close();
            rs.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            rs=null;
            CON.desconectar();
        }
        return registros;
    }
    
    public List<usuarios> seleccionar() {
        List<usuarios> registros=new ArrayList();
        try {
            ps=CON.conectar().prepareStatement("SELECT id, nombre FROM usuarios ORDER BY nombre asc");
            rs=ps.executeQuery();
            while(rs.next()){
            registros.add(new usuarios(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getInt(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getInt(10), rs.getBoolean(11)));            }
            ps.close();
            rs.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            rs=null;
            CON.desconectar();
        }
        return registros;
    }
    
    @Override
    public boolean insertar(usuarios obj) {
        resp = false;
        try {
            ps = CON.conectar().prepareStatement(
                "INSERT INTO usuarios (id_user, nom_user, ape_user, f_nac, doc_identify, tel_user, email_user, contra_user, rol_user, id_emp, activo) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            ps.setInt(1, obj.getId_user());
            ps.setString(2, obj.getNom_user());
            ps.setString(3, obj.getApe_user());
            ps.setString(4, obj.getF_nac());
            ps.setInt(5, obj.getDoc_identify());
            ps.setInt(6, obj.getTel_user());
            ps.setString(7, obj.getEmail_user());
            ps.setString(8, obj.getContra_user());
            ps.setString(9, obj.getRol_user());
            ps.setInt(10, obj.getId_emp());
            ps.setBoolean(11, obj.isActivo());

            if (ps.executeUpdate() > 0) {
                resp = true;
            }

            ps.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally {
            ps = null;
            CON.desconectar();
        }
        return resp;
    }

    @Override
    public boolean actualizar(usuarios obj) {
        resp = false;
        try {
            ps = CON.conectar().prepareStatement(
                "UPDATE usuarios SET nom_user=?, ape_user=?, f_nac=?, doc_identify=?, tel_user=?, email_user=?, contra_user=?, rol_user=?, id_emp=?, activo=? WHERE id_user=?"
            );
            ps.setString(1, obj.getNom_user());
            ps.setString(2, obj.getApe_user());
            ps.setString(3, obj.getF_nac());
            ps.setInt(4, obj.getDoc_identify());
            ps.setInt(5, obj.getTel_user());
            ps.setString(6, obj.getEmail_user());
            ps.setString(7, obj.getContra_user());
            ps.setString(8, obj.getRol_user());
            ps.setInt(9, obj.getId_emp());
            ps.setBoolean(10, obj.isActivo());
            ps.setInt(11, obj.getId_user());

            if (ps.executeUpdate() > 0) {
                resp = true;
            }
            ps.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally {
            ps = null;
            CON.desconectar();
        }
        return resp;
    }


    @Override
    public boolean desactivar(int id) {
        resp=false;
        try {
            ps=CON.conectar().prepareStatement("UPDATE usuarios SET activo=0 WHERE id=?");
            ps.setInt(1, id);
            if (ps.executeUpdate()>0){
                resp=true;
            }
            ps.close();
        }  catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            CON.desconectar();
        }
        return resp;
    }

    @Override
    public boolean activar(int id) {
        resp=false;
        try {
            ps=CON.conectar().prepareStatement("UPDATE usuarios SET activo=1 WHERE id=?");
            ps.setInt(1, id);
            if (ps.executeUpdate()>0){
                resp=true;
            }
            ps.close();
        }  catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            CON.desconectar();
        }
        return resp;
    }

    @Override
    public int total() {
        int totalRegistros=0;
        try {
            ps=CON.conectar().prepareStatement("SELECT COUNT(id) FROM usuarios");            
            rs=ps.executeQuery();
            
            while(rs.next()){
                totalRegistros=rs.getInt("COUNT(id)");
            }            
            ps.close();
            rs.close();
        }  catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            rs=null;
            CON.desconectar();
        }
        return totalRegistros;
    }

    @Override
    public boolean existe(String texto) {
        resp=false;
        try {
            ps=CON.conectar().prepareStatement("SELECT nombre FROM usuarios WHERE nombre=?");
            ps.setString(1, texto);
            rs=ps.executeQuery();
            rs.last();
            if(rs.getRow()>0){
                resp=true;
            }           
            ps.close();
            rs.close();
        }  catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            rs=null;
            CON.desconectar();
        }
        return resp;
    }
    
}
