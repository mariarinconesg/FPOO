package frontend;

public class main extends javax.swing.JFrame {

    public main() {
        initComponents();
        propa1 = new javax.swing.JLabel();
        final_pag = new javax.swing.JLabel();
        iniciar_sesion = new javax.swing.JButton();
        crear_cuenta = new javax.swing.JButton();
        maquillaje = new javax.swing.JButton();
        gift_cards = new javax.swing.JButton();
        kits = new javax.swing.JButton();
        skincare = new javax.swing.JButton();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        propa1 = new javax.swing.JLabel();
        final_pag = new javax.swing.JLabel();
        iniciar_sesion = new javax.swing.JButton();
        crear_cuenta = new javax.swing.JButton();
        maquillaje = new javax.swing.JButton();
        skincare = new javax.swing.JButton();
        brochas = new javax.swing.JButton();
        accesorios = new javax.swing.JButton();
        gift_cards = new javax.swing.JButton();
        kits = new javax.swing.JButton();
        logo = new javax.swing.JLabel();
        escritorio = new javax.swing.JDesktopPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        propa1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/frontend/imagenes/propa 1.png"))); // NOI18N
        getContentPane().add(propa1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, -1, -1));

        final_pag.setIcon(new javax.swing.ImageIcon(getClass().getResource("/frontend/imagenes/final_pag.png"))); // NOI18N
        getContentPane().add(final_pag, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 490, -1, 230));

        iniciar_sesion.setBackground(new java.awt.Color(235, 235, 235));
        iniciar_sesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/frontend/imagenes/inises.png"))); // NOI18N
        iniciar_sesion.setToolTipText("");
        iniciar_sesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iniciar_sesionActionPerformed(evt);
            }
        });
        getContentPane().add(iniciar_sesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(1211, 13, -1, -1));

        crear_cuenta.setBackground(new java.awt.Color(235, 235, 235));
        crear_cuenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/frontend/imagenes/crearc.png"))); // NOI18N
        crear_cuenta.setToolTipText("");
        crear_cuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                crear_cuentaActionPerformed(evt);
            }
        });
        getContentPane().add(crear_cuenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(1045, 15, -1, -1));

        maquillaje.setBackground(new java.awt.Color(235, 235, 235));
        maquillaje.setIcon(new javax.swing.ImageIcon(getClass().getResource("/frontend/imagenes/maquillaje.png"))); // NOI18N
        maquillaje.setToolTipText("");
        maquillaje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maquillajeActionPerformed(evt);
            }
        });
        getContentPane().add(maquillaje, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 110, -1, -1));

        skincare.setBackground(new java.awt.Color(235, 235, 235));
        skincare.setIcon(new javax.swing.ImageIcon(getClass().getResource("/frontend/imagenes/skincare.png"))); // NOI18N
        skincare.setToolTipText("");
        skincare.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                skincareActionPerformed(evt);
            }
        });
        getContentPane().add(skincare, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 110, -1, -1));

        brochas.setBackground(new java.awt.Color(235, 235, 235));
        brochas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/frontend/imagenes/brochas.png"))); // NOI18N
        brochas.setToolTipText("");
        brochas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brochasActionPerformed(evt);
            }
        });
        getContentPane().add(brochas, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 110, -1, -1));

        accesorios.setBackground(new java.awt.Color(235, 235, 235));
        accesorios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/frontend/imagenes/accesorios.png"))); // NOI18N
        accesorios.setToolTipText("");
        accesorios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accesoriosActionPerformed(evt);
            }
        });
        getContentPane().add(accesorios, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 110, -1, -1));

        gift_cards.setBackground(new java.awt.Color(235, 235, 235));
        gift_cards.setIcon(new javax.swing.ImageIcon(getClass().getResource("/frontend/imagenes/giftcard.png"))); // NOI18N
        gift_cards.setToolTipText("");
        gift_cards.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gift_cardsActionPerformed(evt);
            }
        });
        getContentPane().add(gift_cards, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 110, -1, -1));

        kits.setBackground(new java.awt.Color(235, 235, 235));
        kits.setIcon(new javax.swing.ImageIcon(getClass().getResource("/frontend/imagenes/kits.png"))); // NOI18N
        kits.setToolTipText("");
        kits.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kitsActionPerformed(evt);
            }
        });
        getContentPane().add(kits, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 110, -1, -1));

        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/frontend/imagenes/logo.png"))); // NOI18N
        getContentPane().add(logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 6, -1, -1));

        javax.swing.GroupLayout escritorioLayout = new javax.swing.GroupLayout(escritorio);
        escritorio.setLayout(escritorioLayout);
        escritorioLayout.setHorizontalGroup(
            escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1366, Short.MAX_VALUE)
        );
        escritorioLayout.setVerticalGroup(
            escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 710, Short.MAX_VALUE)
        );

        getContentPane().add(escritorio, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 710));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void maquillajeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maquillajeActionPerformed
        // TODO add your handling code here:
        intermaquillaje intermaq = new intermaquillaje(); // Crear instancia de la ventana interna
        escritorio.add(intermaq); // Agregar la ventana al DesktopPane
        intermaq.setVisible(true); // Hacer visible la ventana
    }//GEN-LAST:event_maquillajeActionPerformed

    private void gift_cardsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gift_cardsActionPerformed
        intergiftcards intgift = new intergiftcards();
        escritorio.add(intgift); // Suponiendo que "escritorio" es tu JDesktopPane
        intgift.setVisible(true);
    }//GEN-LAST:event_gift_cardsActionPerformed

    private void kitsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kitsActionPerformed
        interkits interkits = new interkits();
        escritorio.add(interkits); // Suponiendo que "escritorio" es tu JDesktopPane
        interkits.setVisible(true);
    }//GEN-LAST:event_kitsActionPerformed

    private void skincareActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_skincareActionPerformed
        interskincare intskin = new interskincare();
        escritorio.add(intskin); // Suponiendo que "escritorio" es tu JDesktopPane
        intskin.setVisible(true);
    }//GEN-LAST:event_skincareActionPerformed

    private void brochasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brochasActionPerformed
        interbrochas intbro = new interbrochas();
        escritorio.add(intbro); // Suponiendo que "escritorio" es tu JDesktopPane
        intbro.setVisible(true);
    }//GEN-LAST:event_brochasActionPerformed

    private void accesoriosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accesoriosActionPerformed
        // TODO add your handling code here:
        interaccesorios intacc = new interaccesorios();
        escritorio.add(intacc); // Suponiendo que "escritorio" es tu JDesktopPane
        intacc.setVisible(true);
    }//GEN-LAST:event_accesoriosActionPerformed

    private void crear_cuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_crear_cuentaActionPerformed
        // TODO add your handling code here:
        intercrearcuenta intcc = new intercrearcuenta();
        escritorio.add(intcc); // Suponiendo que "escritorio" es tu JDesktopPane
        intcc.setVisible(true);
    }//GEN-LAST:event_crear_cuentaActionPerformed

    private void iniciar_sesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iniciar_sesionActionPerformed
        // TODO add your handling code here:
        interinises intis = new interinises();
        escritorio.add(intis); // Suponiendo que "escritorio" es tu JDesktopPane
        intis.setVisible(true);
    }//GEN-LAST:event_iniciar_sesionActionPerformed

    public static void main(String args[]) {
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton accesorios;
    private javax.swing.JButton brochas;
    private javax.swing.JButton crear_cuenta;
    private javax.swing.JDesktopPane escritorio;
    private javax.swing.JLabel final_pag;
    private javax.swing.JButton gift_cards;
    private javax.swing.JButton iniciar_sesion;
    private javax.swing.JButton kits;
    private javax.swing.JLabel logo;
    private javax.swing.JButton maquillaje;
    private javax.swing.JLabel propa1;
    private javax.swing.JButton skincare;
    // End of variables declaration//GEN-END:variables
}
