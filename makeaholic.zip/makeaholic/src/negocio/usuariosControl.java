package negocio;
import datos.usuariosDao;
import entidades.usuarios;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class usuariosControl {
    private final usuariosDao DATOS;
    private usuarios obj;
    private DefaultTableModel modeloTabla;
    public int registrosMostrados;
    
    public usuariosControl(){
        this.DATOS=new usuariosDao();
        this.obj=new usuarios();
        this.registrosMostrados=0;
    }
    
    public DefaultTableModel listar(String texto){
        List<usuarios> lista=new ArrayList();
        lista.addAll(DATOS.listar(texto));
        
        String[] titulos={"Id","Nombre","Apellido","Fecha de nacimiento","Documento de identificacion","Telefono","Email","Contraseña","Rol de usuario","Id de empresa","Estado"};
        this.modeloTabla=new DefaultTableModel(null,titulos);        
        
        String estado;
        String[] registro = new String[4];
        
        this.registrosMostrados=0;
        for (usuarios item:lista){
            if (item.isActivo()){
                estado="Activo";
            } else{
                estado="Inactivo";
            }
            registro[0]=Integer.toString(item.getId_user());
            registro[1]=item.getNom_user();
            registro[2]=item.getApe_user();
            registro[3]=item.getF_nac();
            registro[4]=item.getDoc_identify();
            registro[5]=item.getTel_user();
            registro[6]=item.getEmail_user();
            registro[7]=item.getContra_user();
            registro[8]=item.getRol_user();
            registro[9]=Integer.toString(item.getId_emp());            
            registro[11]=estado;
            this.modeloTabla.addRow(registro);
            this.registrosMostrados=this.registrosMostrados+1;
        }
        return this.modeloTabla;
    }
    
 public String insertar(String nom_user, String ape_user, String f_nac, String doc_identify, String tel_user, String email_user, String contra_user, String rol_user, int id_emp, boolean activo) {
        if (DATOS.existe(email_user)) {
            return "El registro ya existe.";
        } else {
            obj.setNom_user(nom_user);
            obj.setApe_user(ape_user);
            obj.setF_nac(f_nac);
            obj.setDoc_identify(doc_identify);
            obj.setTel_user(tel_user);
            obj.setEmail_user(email_user);
            obj.setContra_user(contra_user);
            obj.setRol_user(rol_user);
            obj.setId_emp(id_emp);
            obj.setActivo(activo);

            if (DATOS.insertar(obj)) {
                return "OK";
            } else {
                return "Error en el registro.";
            }
        }
    }
    
    public String actualizarUsuario(int id_user, String nom_user, String ape_user, String f_nac, String doc_identify, String tel_user, String email_user, String emailAnt, String contra_user, String rol_user, int id_emp, boolean activo) {
        usuarios obj = new usuarios(id_user, nom_user, ape_user, f_nac, doc_identify, tel_user, email_user, contra_user, rol_user, id_emp, activo);
        if (email_user.equals(emailAnt)) {
            if (DATOS.actualizar(obj)) {
                return "OK";
            } else {
                return "Error en la actualización.";
            }
        } else {
            if (DATOS.existe(email_user)) {
                return "El usuario con este correo ya existe.";
            } else {
                if (DATOS.actualizar(obj)) {
                    return "OK";
                } else {
                    return "Error en la actualización.";
                }
            }
        }
    }

    
    public String desactivar(int id){
        if (DATOS.desactivar(id)){
            return "OK";
        }else{
            return "No se puede desactivar el registro";
        }
    }
    
    public String activar(int id){
        if (DATOS.activar(id)){
            return "OK";
        }else{
            return "No se puede activar el registro";
        }
    }
    
    public int total(){
        return DATOS.total();
    }
    
    public int totalMostrados(){
        return this.registrosMostrados;
    }
}