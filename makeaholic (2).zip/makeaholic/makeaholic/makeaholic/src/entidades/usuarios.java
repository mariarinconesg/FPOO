package entidades;

public class usuarios {
    //Colocar los atributos de la base de datos del polimorfismo
   private int id_user;
   private String nom_user;
   private String ape_user;
   private String f_nac;
   private int doc_identify;
   private int tel_user;
   private String email_user;
   private String contra_user;
   private String rol_user;
   private int id_emp;
   private boolean activo;

   //Invocar los atributos de la tabla
    public usuarios(int id_user, String nom_user, String ape_user, String f_nac, int doc_identify, int tel_user, String email_user, String contra_user, String rol_user, int id_emp, boolean activo) {
        this.id_user = id_user;
        this.nom_user = nom_user;
        this.ape_user = ape_user;
        this.f_nac = f_nac;
        this.doc_identify = doc_identify;
        this.tel_user = tel_user;
        this.email_user = email_user;
        this.contra_user = contra_user;
        this.rol_user = rol_user;
        this.id_emp = id_emp;
        this.activo = activo;
    }

    public usuarios() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    //Capturar los datos del formulario
    public int getId_user() {
        return id_user;
    }

    public String getNom_user() {
        return nom_user;
    }

    public String getApe_user() {
        return ape_user;
    }

    public String getF_nac() {
        return f_nac;
    }

    public int getDoc_identify() {
        return doc_identify;
    }

    public int getTel_user() {
        return tel_user;
    }

    public String getEmail_user() {
        return email_user;
    }

    public String getContra_user() {
        return contra_user;
    }

    public String getRol_user() {
        return rol_user;
    }

    public int getId_emp() {
        return id_emp;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }

    public void setNom_user(String nom_user) {
        this.nom_user = nom_user;
    }

    public void setApe_user(String ape_user) {
        this.ape_user = ape_user;
    }

    public void setF_nac(String f_nac) {
        this.f_nac = f_nac;
    }

    public void setDoc_identify(int doc_identify) {
        this.doc_identify = doc_identify;
    }

    public void setTel_user(int tel_user) {
        this.tel_user = tel_user;
    }

    public void setEmail_user(String email_user) {
        this.email_user = email_user;
    }

    public void setContra_user(String contra_user) {
        this.contra_user = contra_user;
    }

    public void setRol_user(String rol_user) {
        this.rol_user = rol_user;
    }

    public void setId_emp(int id_emp) {
        this.id_emp = id_emp;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    //Verificar lo que se ingresara en la base de datos
    @Override
    public String toString() {
        return "usuarios{" + "id_user=" + id_user + ", nom_user=" + nom_user + ", ape_user=" + ape_user + ", f_nac=" + f_nac + ", doc_identify=" + doc_identify + ", tel_user=" + tel_user + ", email_user=" + email_user + ", contra_user=" + contra_user + ", rol_user=" + rol_user + ", id_emp=" + id_emp + ", activo=" + activo + '}';
    }
   
}